# Currency Morphism

## Quickstart

```bash
make setup
```

## Run smoke

```bash
python scripts/smoke.py
```

## Run tests

```bash
make test
```

## Run lint

```bash
make lint
```
